/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Antonio
 */
@WebServlet(urlPatterns = {"/purchase"})
public class purchase extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             /* TODO output your page here. You may use following sample code. */
            //Arizona Diamond Backs
            String arizona = request.getParameter("Arizona");
            Double arizonaAmount = Double.valueOf(arizona.trim());
            double arizonaAmountPrice = 35 * arizonaAmount;
            
            //Anaheim Angels
            String anaheim = request.getParameter("Anaheim");
            String anaheimHatSize = request.getParameter("anaheimHatSize");
            Double anaheimAmount = Double.valueOf(arizona.trim());
            double anaheimAmountPrice = 35 * anaheimAmount;
            
            
            out.print("<table align=center border= '3' cellpadding='1' cellspacing='1' width=50% style='text-align:right'>");
            out.print("<tr>");
            out.print("<td><b> Product Name </b></td>");
            out.print("<td><b> Hat Size </b></td>");
            out.print("<td><b> Amount </b></td>");
            out.print("<td><b> Price </b></td>");
            out.print("</tr>");
            out.print("<tr>");
            out.print("<td>"+ "Arizona" + "</td>" + "<td>"+ anaheimHatSize + "</td>"  + "<td>" + arizonaAmount + "</td>" + "<td>" + arizonaAmountPrice + "</td>");
            out.print("</tr>");
            out.print("<tr>");
            out.print("<td>"+ "Anaheim" + "</td>" + "<td>" + anaheim + "</td>");
            out.print("</tr>");
            
            
            out.print("</table>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
